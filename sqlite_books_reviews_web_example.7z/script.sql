select title, count(title) from books
group by title